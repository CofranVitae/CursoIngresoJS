function mostrar()
{

var clave = prompt("ingrese el número clave.");


}//FIN DE LA FUNCIÓN
